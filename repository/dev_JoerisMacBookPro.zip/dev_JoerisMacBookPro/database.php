<?php

return array(

	'fetch' => PDO::FETCH_CLASS,

	'default' => 'documents',

	'connections' => array(

		'documents' => array(
			'driver'    	=> 'mysql',
			'host'      	=> '127.0.0.1',
			'port'			=> '8889',
			
			'database'  	=> 'dev_2014-0121',
			'username'  	=> 'root',
			'password'  	=> 'root',
			'charset'   	=> 'utf8',
			'collation' 	=> 'utf8_unicode_ci',
			'prefix'    	=> '',
		),

	)

);
